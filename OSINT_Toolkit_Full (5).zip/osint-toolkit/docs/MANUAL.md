# OSINT Toolkit Manual

Refer to README or GitHub for full setup.